# ÇELİK CEPHE — Birleşik Muharebe (Kara + Hava)

War Thunder tarzı tarayıcı oyunu (three.js r128). Hangar, araştırma ağacı, kadro yuvaları, SP ekonomisi ve 6'ya 6 kara + hava hakimiyet muharebesi.

## Hangar
- Seçili araç 3B hangarda döner tablada sergilenir (sürükle: döndür, tekerlek: yakınlaştır).
- Alttaki 5 kadro yuvasına araç yerleştir (⇄ ile değiştir). Muharebede bu kadroyla doğarsın.
- Üstte SL (gümüş) ve RP (araştırma puanı), seviye çubuğu, Arcade/Gerçekçi seçimi ve SAVAŞA! düğmesi.
- İlerleme tarayıcıda saklanır (localStorage).

## Araştırma ağacı (ABD)
| Rank | Ana muharebe tankı | Piyade savaş aracı | Taarruz uçağı |
|---|---|---|---|
| V | — | M2A2 Bradley (8.3) | — |
| VI | M1 Abrams (10.0) | M2A2 ODS (9.3) | A-10A erken (10.0) |
| VII | M1A1 Abrams (11.0) | M3A3 Bradley (9.7) | A-10A geç (10.7) |
| VIII | M1A2 Abrams (11.7) | M2A3 Bradley (10.0) | A-10C (11.3, AGM-65 Maverick) |

Araştırma RP, satın alma SL ister; ikisi de muharebe sonunda puanına göre kazanılır. Rakipler kadronun en yüksek BR'sine göre eşleşir.

## Almanya
| Rank | Tank | Uçak |
|---|---|---|
| II | Pz.Kpfw. III Ausf. J (3.0) — 5 cm KwK 39 L/60, PzGr 39 / PzGr 40 | Ju 87 G-2 Stuka (3.7) — 2× BK 3,7 cm tanksavar topu, otomatik arka nişancı |

ABD ağacına ayrıca **Spitfire Mk Vb** (3.7) avcı uçağı eklendi. Hangarın sol üstündeki ABD / ALMANYA düğmeleriyle ulus değiştirilir; her ulusun kendi kadrosu ve ağacı vardır.

## Hava muharebesi
Hangarda **HAVA MUHAREBESİ** seçilince 6'ya 6 it dalaşı başlar. Kadrondaki uçaklarla sınırsız doğarsın; düşman uçaklarını düşürerek biletlerini eritirsin. Rakipler seçili uçağın BR'sine göre eşleşir (ör. Spitfire ↔ Ju 87).

## Uçuş fiziği (GökSim motoru)
Uçaklar GökSim'in 6 serbestlik dereceli uçuş modeliyle uçar: kaldırma/sürükleme/itki/yerçekimi gerçek kuvvetlerdir, perdövites (stall) eğrisi vardır, kumanda yüzeylerinin etkisi dinamik basınçla ölçeklenir. War Thunder tarzı fare-nişan eğitmeni farenin gösterdiği yönü irtifa dümeni, kanatçık ve istikamet dümenine çevirir; hücum açısı ve G sınırlayıcısı uçağı perdövitesten korur. Uçak verileri `js/game.js` içindeki `AERO` tablosundadır (kütle, kanat alanı, CL/CD katsayıları, motor itkisi, kumanda yetkileri).

Hava muharebesi sahası 6,4 × 6,4 km'dir (kara savaşında uçaklar için 2,5 km).

## Çok oyunculu (arkadaşlarla, en fazla 12 kişi)
Rocket Arena 3D ile aynı mantık: sunucu yok, **odayı kuranın tarayıcısı sunucu olur** (PeerJS / WebRTC).
1. Hangarda **ÇOK OYUNCULU** → adını yaz → **TANK vs TANK** ya da **UÇAK vs UÇAK** seç → **ODA KUR**.
2. 4 karakterlik oda kodunu (veya **DAVET BAĞLANTISINI KOPYALA**) arkadaşlarına gönder; onlar kodu yazıp **KATIL**'a basar.
3. Misafirler **TAKIM DEĞİŞTİR** ile Mavi/Kızıl arasında geçer; boş yerler istenirse botla dolar. Odayı kuran **MUHAREBEYİ BAŞLAT**'a basar.
4. Herkes kendi hangar kadrosundaki araçlarla sınırsız doğar; biletler biten takım kaybeder.

Notlar:
- Odayı kuranın oyun sekmesi muharebe boyunca **açık ve önde** kalmalı (arka plana alınan sekmeyi tarayıcı yavaşlatır). En güçlü cihaz oda kursun.
- Farklı evlerden bağlanırken doğrudan bağlantı kurulamazsa `js/game.js` içindeki `const TURN={server:'',username:'',password:''}` satırına expressturn.com bilgilerini yaz (Rocket Arena'dakiyle aynı bilgiler çalışır).

## Muharebe
- 1,6 km'lik muharebe alanı, ufukta dağlar, nehir (sığ geçitler, suda tanklar yavaşlar), köyler ve kasaba.
- SP: ilk kara aracı ücretsiz; imha, isabet ve nokta ele geçirme SP kazandırır. Uçak SP ister. Düşman da Su-25 çağırır.
- Açıya bağlı zırh delme, sekme, mürettebat/modül hasarı, vuruş kamerası, lazer menzil ölçerli nişangâh.

## Kontroller
**Tank:** W/S gaz-geri · A/D dönüş · Fare nişan · Sol tık/Space ateş · Sağ tık/Shift nişangâh · 1-2-3 mühimmat · R hızlı doldur · X onarım · F söndür
**Uçak:** Fare uçuş yönü · W/S gaz · A/D yatış · Sol tık top · R/E roket · Space bomba · Q Maverick (A-10C) · Sağ tık zoom
**Genel:** J araçtan ayrıl · C serbest bakış · Tab skor · Esc duraklat

## Çalıştırma
Dosyaya çift tıklayarak (file://) açılmaz. GitHub Pages'te doğrudan çalışır; yerelde `python3 -m http.server 8000` → `http://localhost:8000`.
